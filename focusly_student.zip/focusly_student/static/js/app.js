document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  const savedTheme = localStorage.getItem('focusly-theme');
  if (savedTheme === 'light') body.classList.add('light-theme');
  if (themeToggle) {
    themeToggle.textContent = body.classList.contains('light-theme') ? '☾' : '☼';
    themeToggle.addEventListener('click', () => {
      body.classList.toggle('light-theme');
      const light = body.classList.contains('light-theme');
      localStorage.setItem('focusly-theme', light ? 'light' : 'dark');
      themeToggle.textContent = light ? '☾' : '☼';
    });
  }
  const sidebar = document.getElementById('sidebar');
  const scrim = document.getElementById('mobileScrim');
  const menuToggle = document.getElementById('menuToggle');
  function closeMenu(){ sidebar?.classList.remove('open'); scrim?.classList.remove('visible'); }
  menuToggle?.addEventListener('click', () => { sidebar?.classList.toggle('open'); scrim?.classList.toggle('visible'); });
  scrim?.addEventListener('click', closeMenu);

  let totalSeconds = 25 * 60, remaining = totalSeconds, timer = null, running = false;
  const display = document.getElementById('timerDisplay'), start = document.getElementById('timerStart');
  const caption = document.getElementById('timerCaption'), ring = document.getElementById('timerRing');
  const reset = document.getElementById('timerReset');
  const modes = document.querySelectorAll('.mode-btn');
  function renderTimer(){
    if (!display) return;
    display.textContent = `${String(Math.floor(remaining/60)).padStart(2,'0')}:${String(remaining%60).padStart(2,'0')}`;
    if (ring) ring.style.setProperty('--progress', `${((totalSeconds-remaining)/totalSeconds)*100}%`);
  }
  function stopTimer(){ clearInterval(timer); timer = null; running = false; if(start) start.innerHTML = '▶ Start focus'; }
  start?.addEventListener('click', () => {
    if (running) { stopTimer(); caption.textContent = 'Paused. Take a breath when you need one.'; return; }
    running = true; start.innerHTML = 'Ⅱ Pause session'; caption.textContent = 'You are doing great. Stay with it.';
    timer = setInterval(() => { remaining--; renderTimer(); if (remaining <= 0) { stopTimer(); caption.textContent = 'Session complete. Take a well-earned break! ✦'; if (navigator.vibrate) navigator.vibrate([150,80,150]); } }, 1000);
  });
  reset?.addEventListener('click', () => { stopTimer(); remaining = totalSeconds; renderTimer(); caption.textContent = 'One thing at a time. You’ve got this.'; });
  modes.forEach(btn => btn.addEventListener('click', () => {
    stopTimer(); modes.forEach(m => m.classList.remove('selected')); btn.classList.add('selected');
    totalSeconds = Number(btn.dataset.minutes) * 60; remaining = totalSeconds;
    caption.textContent = btn.dataset.minutes === '25' ? 'One thing at a time. You’ve got this.' : 'A little reset goes a long way.';
    renderTimer();
  }));
  renderTimer();
});